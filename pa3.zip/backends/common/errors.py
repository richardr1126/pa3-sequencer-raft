"""Common backend HTTP-layer errors."""


class ApiError(Exception):
    """Application error carrying an HTTP status and stable error code."""

    def __init__(self, status_code: int, code: str, message: str):
        super().__init__(message)
        self.status_code = status_code
        self.code = code
        self.message = message

